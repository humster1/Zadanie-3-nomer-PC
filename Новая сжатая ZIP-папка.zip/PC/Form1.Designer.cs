﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbCPUName = new System.Windows.Forms.TextBox();
            this.tbCPUFrequency = new System.Windows.Forms.TextBox();
            this.tbRAMAmount = new System.Windows.Forms.TextBox();
            this.btnAddConfiguration = new System.Windows.Forms.Button();
            this.lbConfigurations = new System.Windows.Forms.ListBox();
            this.tbCPUName2 = new System.Windows.Forms.TextBox();
            this.tbCPUFrequency2 = new System.Windows.Forms.TextBox();
            this.tbRAMAmount2 = new System.Windows.Forms.TextBox();
            this.tbHDDSize = new System.Windows.Forms.TextBox();
            this.btnAddComputer = new System.Windows.Forms.Button();
            this.lbComputers = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tbCPUName
            // 
            this.tbCPUName.Location = new System.Drawing.Point(53, 85);
            this.tbCPUName.Name = "tbCPUName";
            this.tbCPUName.Size = new System.Drawing.Size(100, 20);
            this.tbCPUName.TabIndex = 0;
            // 
            // tbCPUFrequency
            // 
            this.tbCPUFrequency.Location = new System.Drawing.Point(53, 134);
            this.tbCPUFrequency.Name = "tbCPUFrequency";
            this.tbCPUFrequency.Size = new System.Drawing.Size(100, 20);
            this.tbCPUFrequency.TabIndex = 1;
            // 
            // tbRAMAmount
            // 
            this.tbRAMAmount.Location = new System.Drawing.Point(53, 180);
            this.tbRAMAmount.Name = "tbRAMAmount";
            this.tbRAMAmount.Size = new System.Drawing.Size(100, 20);
            this.tbRAMAmount.TabIndex = 2;
            // 
            // btnAddConfiguration
            // 
            this.btnAddConfiguration.Location = new System.Drawing.Point(62, 225);
            this.btnAddConfiguration.Name = "btnAddConfiguration";
            this.btnAddConfiguration.Size = new System.Drawing.Size(75, 23);
            this.btnAddConfiguration.TabIndex = 3;
            this.btnAddConfiguration.Text = "button1";
            this.btnAddConfiguration.UseVisualStyleBackColor = true;
            this.btnAddConfiguration.Click += new System.EventHandler(this.btnAddConfiguration_Click);
            // 
            // lbConfigurations
            // 
            this.lbConfigurations.FormattingEnabled = true;
            this.lbConfigurations.Location = new System.Drawing.Point(172, 49);
            this.lbConfigurations.Name = "lbConfigurations";
            this.lbConfigurations.Size = new System.Drawing.Size(207, 199);
            this.lbConfigurations.TabIndex = 4;
            this.lbConfigurations.SelectedIndexChanged += new System.EventHandler(this.lbConfigurations_SelectedIndexChanged_1);
            // 
            // tbCPUName2
            // 
            this.tbCPUName2.Location = new System.Drawing.Point(413, 298);
            this.tbCPUName2.Name = "tbCPUName2";
            this.tbCPUName2.Size = new System.Drawing.Size(100, 20);
            this.tbCPUName2.TabIndex = 5;
            // 
            // tbCPUFrequency2
            // 
            this.tbCPUFrequency2.Location = new System.Drawing.Point(413, 336);
            this.tbCPUFrequency2.Name = "tbCPUFrequency2";
            this.tbCPUFrequency2.Size = new System.Drawing.Size(100, 20);
            this.tbCPUFrequency2.TabIndex = 6;
            // 
            // tbRAMAmount2
            // 
            this.tbRAMAmount2.Location = new System.Drawing.Point(413, 373);
            this.tbRAMAmount2.Name = "tbRAMAmount2";
            this.tbRAMAmount2.Size = new System.Drawing.Size(100, 20);
            this.tbRAMAmount2.TabIndex = 7;
            // 
            // tbHDDSize
            // 
            this.tbHDDSize.Location = new System.Drawing.Point(413, 415);
            this.tbHDDSize.Name = "tbHDDSize";
            this.tbHDDSize.Size = new System.Drawing.Size(100, 20);
            this.tbHDDSize.TabIndex = 8;
            // 
            // btnAddComputer
            // 
            this.btnAddComputer.Location = new System.Drawing.Point(428, 458);
            this.btnAddComputer.Name = "btnAddComputer";
            this.btnAddComputer.Size = new System.Drawing.Size(75, 23);
            this.btnAddComputer.TabIndex = 9;
            this.btnAddComputer.Text = "button1";
            this.btnAddComputer.UseVisualStyleBackColor = true;
            this.btnAddComputer.Click += new System.EventHandler(this.btnAddComputer_Click);
            // 
            // lbComputers
            // 
            this.lbComputers.FormattingEnabled = true;
            this.lbComputers.Location = new System.Drawing.Point(175, 298);
            this.lbComputers.Name = "lbComputers";
            this.lbComputers.Size = new System.Drawing.Size(207, 199);
            this.lbComputers.TabIndex = 10;
            this.lbComputers.SelectedIndexChanged += new System.EventHandler(this.lbComputers_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(634, 611);
            this.Controls.Add(this.lbComputers);
            this.Controls.Add(this.btnAddComputer);
            this.Controls.Add(this.tbHDDSize);
            this.Controls.Add(this.tbRAMAmount2);
            this.Controls.Add(this.tbCPUFrequency2);
            this.Controls.Add(this.tbCPUName2);
            this.Controls.Add(this.lbConfigurations);
            this.Controls.Add(this.btnAddConfiguration);
            this.Controls.Add(this.tbRAMAmount);
            this.Controls.Add(this.tbCPUFrequency);
            this.Controls.Add(this.tbCPUName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbCPUName;
        private System.Windows.Forms.TextBox tbCPUFrequency;
        private System.Windows.Forms.TextBox tbRAMAmount;
        private System.Windows.Forms.Button btnAddConfiguration;
        private System.Windows.Forms.ListBox lbConfigurations;
        private System.Windows.Forms.TextBox tbCPUName2;
        private System.Windows.Forms.TextBox tbCPUFrequency2;
        private System.Windows.Forms.TextBox tbRAMAmount2;
        private System.Windows.Forms.TextBox tbHDDSize;
        private System.Windows.Forms.Button btnAddComputer;
        private System.Windows.Forms.ListBox lbComputers;
    }
}

