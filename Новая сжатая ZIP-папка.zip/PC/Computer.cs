﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Computer : PCConfiguration
    {
        // Размер жесткого диска компьютера.
        public int HDDSize { get; set; }

        // Создает экземпляр класса Computer с заданными параметрами.
        public Computer(string nameCPU, float cpuBaseFrequency, int ramAmount, int hddSize) :
            base(nameCPU, cpuBaseFrequency, ramAmount)
        {
            HDDSize = hddSize;
        }

        /// Возвращает рассчитанный показатель качества компьютера.
        public new float GetQuality()
        {
            return (float)(base.GetQuality() + (0.3 * CPUBaseFrequency) + RAMAmount + HDDSize);
        }

        public void PrintComputerInfo()
        {
            MessageBox.Show($"CPU name: {NameCPU}\n" +
                            $"CPU base frequency: {CPUBaseFrequency} MHz\n" +
                            $"RAM amount: {RAMAmount} GB\n" +
                            $"HDD size: {HDDSize} GB\n" +
                            $"Computer quality: {GetQuality()}");
        }

        // Создает экземпляр класса Computer на основе списка строк.
        public static new Computer FromList(List<string> computerList)
        {
            return new Computer(computerList[0], Convert.ToSingle(computerList[1]), Convert.ToInt32(computerList[2]), Convert.ToInt32(computerList[3]));
        }

        public static new Computer FromDict(Dictionary<string, string> computerDict)
        {
            return new Computer(computerDict["NameCPU"], Convert.ToInt32(computerDict["CPUBaseFrequency"]),
                                Convert.ToInt32(computerDict["RAMAmount"]), Convert.ToInt32(computerDict["HDDSize"]));
        }
    }
}
