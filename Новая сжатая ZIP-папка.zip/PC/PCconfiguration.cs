﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

public class PCConfiguration
    {
    public string NameCPU { get; set; }
    public float CPUBaseFrequency { get; set; }
    public int RAMAmount { get; set; }

    public PCConfiguration(string nameCPU, float cpuBaseFrequency, int ramAmount)
    {
        NameCPU = nameCPU;
        CPUBaseFrequency = cpuBaseFrequency;
        RAMAmount = ramAmount;
    }

    public float GetQuality()
    {
        return 10 * CPUBaseFrequency + 5 * RAMAmount;
    }


    public static PCConfiguration FromList(List<string> configurationList)
    {
        return new PCConfiguration(configurationList[0], Convert.ToSingle(configurationList[1]), Convert.ToInt32(configurationList[2]));
    }

    public static PCConfiguration FromDict(Dictionary<string, string> configurationDict)
    {
        return new PCConfiguration(configurationDict["NameCPU"], Convert.ToInt32(configurationDict["CPUBaseFrequency"]),
                                   Convert.ToInt32(configurationDict["RAMAmount"]));
    }
}

