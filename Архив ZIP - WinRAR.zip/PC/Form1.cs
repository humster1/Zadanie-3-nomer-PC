﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<PCConfiguration> configurations = new List<PCConfiguration>(); // Список конфигураций ПК
        List<Computer> computers = new List<Computer>(); // Список компьютеров

        // Конструктор формы
        public Form1()
        {
            InitializeComponent();
        }
        // Кнопка "Добавить конфигурацию"
        private void btnAddConfiguration_Click(object sender, EventArgs e)
        {
            // Проверка наличия названия процессора
            if (string.IsNullOrEmpty(tbCPUName.Text))
            {
                MessageBox.Show("Введите название процессора");
                return;
            }

            // Проверка корректности ввода частоты процессора
            if (!double.TryParse(tbCPUFrequency.Text, out double cpuFrequency) || cpuFrequency <= 0)
            {
                MessageBox.Show("Введите корректную частоту процессора");
                return;
            }

            // Проверка корректности ввода объема ОЗУ
            if (!int.TryParse(tbRAMAmount.Text, out int ramAmount) || ramAmount <= 0)
            {
                MessageBox.Show("Введите корректный объем оперативной памяти");
                return;
            }

            // Создание списка параметров конфигурации
            List<string> configurationList = new List<string>();
            configurationList.Add(tbCPUName.Text);
            configurationList.Add(tbCPUFrequency.Text);
            configurationList.Add(tbRAMAmount.Text);

            // Создание объекта конфигурации и добавление его в список конфигураций ПК
            PCConfiguration configuration = PCConfiguration.FromList(configurationList);
            configurations.Add(configuration);

            // Добавление названия процессора в список конфигураций на форме
            lbConfigurations.Items.Add(configuration.NameCPU);

            // Очистка полей ввода
            tbCPUName.Clear();
            tbCPUFrequency.Clear();
            tbRAMAmount.Clear();
        }

        // Кнопка "Добавить компьютер"
        private void btnAddComputer_Click(object sender, EventArgs e)
        {
            // Проверка наличия названия процессора
            if (string.IsNullOrEmpty(tbCPUName2.Text))
            {
                MessageBox.Show("Введите название процессора");
                return;
            }
            // Проверка корректности ввода частоты процессора
            if (!float.TryParse(tbCPUFrequency2.Text, out float cpuFrequency) || cpuFrequency <= 0)
            {
                MessageBox.Show("Введите корректную частоту процессора");
                return;
            }
            // Проверка корректности ввода объема ОЗУ
            if (!int.TryParse(tbRAMAmount2.Text, out int ramAmount) || ramAmount <= 0)
            {
                MessageBox.Show("Введите корректный объем оперативной памяти");
                return;
            }
            // Проверка корректности ввода объема жесткого диска
            if (!int.TryParse(tbHDDSize.Text, out int hddSize) || hddSize <= 0)
            {
                MessageBox.Show("Введите корректный объем жесткого диска");
                return;
            }
            // Создание списка параметров компьютера
            List<string> computerList = new List<string>();
            computerList.Add(tbCPUName2.Text);
            computerList.Add(tbCPUFrequency2.Text);
            computerList.Add(tbRAMAmount2.Text);
            computerList.Add(tbHDDSize.Text);

            // Создание объекта компьютера и добавление его в список
            Computer computer = Computer.FromList(computerList);
            computers.Add(computer);

            // Добавление названия процессора в список компьютеров на форме
            lbComputers.Items.Add(computer.NameCPU);

            // Очистка полей ввода
            tbCPUName2.Clear();
            tbCPUFrequency2.Clear();
            tbRAMAmount2.Clear();
            tbHDDSize.Clear();
        }

        // Обработка выбора конфигурации ПК в списке на форме
        private void lbConfigurations_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int selectedConfigurationIndex = lbConfigurations.SelectedIndex;
            // Если элемент выбран
            if (selectedConfigurationIndex > -1)
            {
                // Получение объекта конфигурации ПК из списка конфигураций
                PCConfiguration selectedConfiguration = configurations[selectedConfigurationIndex];
                // Вывод информации о конфигурации на экран
                MessageBox.Show($"CPU name: {selectedConfiguration.NameCPU}\n" +
                                $"CPU base frequency: {selectedConfiguration.CPUBaseFrequency} MHz\n" +
                                $"RAM amount: {selectedConfiguration.RAMAmount} GB\n" +
                                $"Configuration quality: {selectedConfiguration.GetQuality()}");
            }
        }
        // Обработка выбора компьютера в списке на форме
        private void lbComputers_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedComputerIndex = lbComputers.SelectedIndex;
            // Если элемент выбран
            if (selectedComputerIndex > -1)
            {
                // Получение объекта компьютера из списка компьютеров
                Computer selectedComputer = computers[selectedComputerIndex];
                // Вывод информации о компьютере на экран
                MessageBox.Show($"CPU name: {selectedComputer.NameCPU}\n" +
                                $"CPU base frequency: {selectedComputer.CPUBaseFrequency} MHz\n" +
                                $"RAM amount: {selectedComputer.RAMAmount} GB\n" +
                                $"HDD size: {selectedComputer.HDDSize} GB\n" +
                                $"Computer quality: {selectedComputer.GetQuality()}");
            }
        }

        private void button1_Click (object sender, EventArgs e)
        {
            StreamWriter sr = new StreamWriter(@"PCConfiguration.txt", true);
            int selectedConfigurationIndex = lbConfigurations.SelectedIndex;
            PCConfiguration selectedConfiguration = configurations [ selectedConfigurationIndex ];

            sr.WriteLine($"CPU name: {selectedConfiguration.NameCPU}\n" +
                                $"CPU base frequency: {selectedConfiguration.CPUBaseFrequency} MHz\n" +
                                $"RAM amount: {selectedConfiguration.RAMAmount} GB\n" +
                                $"Configuration quality: {selectedConfiguration.GetQuality( )}");
            MessageBox.Show("Файл сохранен!");
            sr.Dispose( );
        }
    }
}    

