﻿using System;
using System.Collections.Generic;
    public class PCconfiguration
    {
        public string NameCPU { get; set; }
        public int cpuBaseFrequency { get; set; }
        public int Ram { get; set; }

        public PCconfiguration(string cpu, int MHz, int ram)
        {
            NameCPU = cpu;
            cpuBaseFrequency = MHz;
            Ram = ram;
        }
    }
}
